package com.teashop.teashop_backend;

import java.util.Scanner;

public class LoginRequest {
    private String email;
    private String password;
    private Scanner scanner = new Scanner(System.in);

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String grabLoginRequest() {
        System.out.print("Enter email: ");
        this.email = scanner.nextLine();
        System.out.print("Enter password: ");
        this.password = scanner.nextLine();
        String loginInfo = email + " " + password;
        return loginInfo;
    }

    public LoginRequest(String loginInfo) {
        String[] splitLoginInfo = loginInfo.split(" ");
        this.email = splitLoginInfo[0];
        this.password = splitLoginInfo[1];
        if (this.email == null || this.password == null) {
            System.out.println("Email or password cannot be null.");
        }
        if (this.email.isEmpty() || this.password.isEmpty()) {
            System.out.println("Email or password cannot be empty.");
        }
        else {
            System.out.println("Login request created successfully.");
        }
    }
}