package com.teashop.teashop_backend.run;

public enum Location {
    INDOOR, OUTDOOR
}
