package com.teashop.teashop_backene;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeashopBackeneApplicationTests {

	@Test
	void contextLoads() {
	}

}
